#ifndef RGB_MODES_H
#define RGB_MODES_H

//void initRGBModes();  initialization ldr_controlde ve rgb_modesda extern ile yapıldığından gerek yok
void setRGBColor(int r, int g, int b);
void setPartyMode();
void setMovieMode();
void setDinnerMode();

#endif