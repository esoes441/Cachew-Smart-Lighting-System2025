#include <WiFi.h>
#include <WebSocketsServer.h>
#include "config.h"
#include "command_parser.h"
#include "wifi_conn.h"

WebSocketsServer webSocket = WebSocketsServer(81);//81 dinlenen port numarasi

void onWebSocketEvent(uint8_t num, WStype_t type, uint8_t * payload, size_t length) {
  if (type == WStype_TEXT) {
    String msg = String((char*)payload);
    parseCommand(msg);  // Unified handler
  }
}

void initWiFi() {
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi connected");
  webSocket.begin();
  webSocket.onEvent(onWebSocketEvent);
}

void handleWebSocket() {
  webSocket.loop();
}

void sendWebSocketMessage(String msg) {  // Remove const
    webSocket.broadcastTXT(msg);
}