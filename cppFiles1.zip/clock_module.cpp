#include "clock_module.h"
#include "config.h"
#include "rgb_modes.h"
#include "ldr_control.h"
#include "wifi_conn.h" // for sendWebSocketMessage or similar

#include <ThreeWire.h>
#include <RtcDS1302.h>
#include <Adafruit_NeoPixel.h>

extern Adafruit_NeoPixel* ledStrips[];

ThreeWire myWire(PIN_DAT, PIN_CLK, PIN_RST); // IO, SCLK, CE
RtcDS1302<ThreeWire> Rtc(myWire);

// Track last sent time
unsigned long lastReportTime = 0;
const unsigned long reportInterval = 30 * 60 * 1000; // 30 minutes

void initRTC() {
  Rtc.Begin();

  if (!Rtc.IsDateTimeValid()) {
    Serial.println("RTC not valid; setting to compile time.");
    Rtc.SetDateTime(RtcDateTime(__DATE__, __TIME__));
  }
}

void updateTimeAndReport() {
  unsigned long now = millis();
  if (now - lastReportTime < reportInterval) return;

  lastReportTime = now;

  RtcDateTime currentTime = Rtc.GetDateTime();
  char timeBuffer[6];
  sprintf(timeBuffer, "%02d:%02d", currentTime.Hour(), currentTime.Minute());

  // Get current mode (assume this is stored globally somewhere) buna bakılacak
  extern String currentMode; // e.g., "party", "movie", etc.

  String modeStatus = currentMode.length() > 0 ? currentMode : "off";

  // Build LED strip info
  String activeStrips = "";
  for (int i = 0; i < NUM_LDR_SENSORS; i++) {
    if (ledStrips[i]) {
      activeStrips += String(LED_PIN[i]);
      if (i < NUM_LDR_SENSORS - 1) activeStrips += ",";
    }
  }

  // Construct JSON message (or any format your backend expects)
  String message = "{";
  message += "\"time\":\"" + String(timeBuffer) + "\",";
  message += "\"mode\":\"" + modeStatus + "\",";
  message += "\"strips\":\"" + (modeStatus == "off" ? "off" : activeStrips) + "\"";
  message += "}";

  // Send to backend
  sendWebSocketMessage(message);  // You should define this in `wifi_conn.cpp`
}
