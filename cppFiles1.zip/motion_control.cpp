#include "motion_control.h"
#include "config.h"
#include "rgb_modes.h"
#include <Arduino.h>

void initMotionSensors() {
  for (int i = 0; i < NUM_PIR_SENSORS; i++) {
    pinMode(PIR_SENSOR_PINS[i], INPUT);
  }
}

void checkAllMotionSensors() {    //özelleştirilecek
  for (int i = 0; i < NUM_PIR_SENSORS; i++) {
    if (digitalRead(PIR_SENSOR_PINS[i]) == HIGH) {
      Serial.printf("Motion detected on PIR #%d\n", i+1);
      setRGBColor(255, 255, 255);  // White light or custom reaction
    }
  }
}
