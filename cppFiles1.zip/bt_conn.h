#ifndef BT_CONN_H
#define BT_CONN_H

void initBluetooth();
void handleBluetooth();

#endif