#ifndef LDR_CONTROL_H
#define LDR_CONTROL_H

void initLightSensors();
void checkAllLightSensors();

#endif