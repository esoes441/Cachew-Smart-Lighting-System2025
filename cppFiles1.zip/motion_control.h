#ifndef MOTION_CONTROL_H
#define MOTION_CONTROL_H

void initMotionSensors();
void checkAllMotionSensors();

#endif