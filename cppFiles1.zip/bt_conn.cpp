#include "BluetoothSerial.h"
#include "command_parser.h"
#include "bt_conn.h"

BluetoothSerial SerialBT;

void initBluetooth() {
  SerialBT.begin("ESP32-Lighting");
}

void handleBluetooth() {
  if (SerialBT.available()) {
    String msg = SerialBT.readStringUntil('\n');
    parseCommand(msg);
  }
}