#include "command_parser.h"
#include "rgb_modes.h"
#include "ldr_control.h"

void parseCommand(String cmd) {
  cmd.trim();
  cmd.toLowerCase();

  if (cmd == "mode:party") {
    setPartyMode();
  } else if (cmd == "mode:movie") {
    setMovieMode();
  } else if (cmd == "mode:dinner") {
    setDinnerMode();
  } else if (cmd.startsWith("color:")) {
    int r, g, b;
    sscanf(cmd.c_str(), "color:%d,%d,%d", &r, &g, &b);
    setRGBColor(r, g, b);  // Direct RGB control
  }
}