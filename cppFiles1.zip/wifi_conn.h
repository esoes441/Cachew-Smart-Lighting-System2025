#ifndef WIFI_CONN_H
#define WIFI_CONN_H
#include <Arduino.h>

void initWiFi();
void handleWebSocket();
void sendWebSocketMessage(const String& msg); //rtc mesaji için

#endif
