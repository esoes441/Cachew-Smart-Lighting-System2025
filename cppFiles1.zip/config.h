#ifndef CONFIG_H
#define CONFIG_H

// Pin configuration
#define NUM_PIR_SENSORS 3
#define NUM_LDR_SENSORS 3
#define NUM_LEDS 40 //8x5

const int PIR_SENSOR_PINS[NUM_PIR_SENSORS] = {13, 14, 15};
const int LDR_SENSOR_PINS[NUM_LDR_SENSORS] = {34, 35, 36};
#define LED_PIN  25
#define PIN_CLK  18 //rtc
#define PIN_DAT  19 //rtc
#define PIN_RST  4  //rtc

#define MINUTE 60000 // for converting milliseconds to a minute
#define SECOND 1000 // for converting milliseconds to a second

// Thresholds
#define LOW_LIGHT_THRESHOLD   3000  
#define LOWER_LIGHT_THRESHOLD   1800

// Wi-Fi & Flask
#define WIFI_SSID         "CacheCrew"
#define WIFI_PASSWORD     "Cachew"
#define FLASK_SERVER_URL  "http://your-server-ip:5000/update"

#endif
