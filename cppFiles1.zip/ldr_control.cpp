#include "ldr_control.h"
#include "config.h"
#include <Adafruit_NeoPixel.h>

Adafruit_NeoPixel* ledStrips[NUM_LDR_SENSORS];

void initLightingControl() {
  for (int i = 0; i < NUM_LDR_SENSORS; i++) {
    ledStrips[i] = new Adafruit_NeoPixel(NUM_LEDS, LED_PIN[i], NEO_GRB + NEO_KHZ800);
    ledStrips[i]->begin();
    ledStrips[i]->show(); // Turn off initially
  }
}

void updateLightingFromLDR(int ldrValue, Adafruit_NeoPixel* strip) {
  int brightness = map(ldrValue, 0, 4095, 255, 0);

  uint8_t r, g, b;

  if (ldrValue < LOWER_LIGHT_THRESHOLD) {
    r = g = b = brightness;
  } else if (ldrValue < LOW_LIGHT_THRESHOLD) {
    r = brightness;
    g = brightness / 2;
    b = 0;
  } else {
    r = g = b = 0;
  }

  for (int i = 0; i < NUM_LEDS; i++) {
    strip->setPixelColor(i, strip->Color(r, g, b));
  }
  strip->show();
}

void updateAllLighting() {
  for (int i = 0; i < NUM_LDR_SENSORS; i++) {
    int ldrVal = analogRead(LDR_SENSOR_PINS[i]);
    Serial.printf("LDR #%d value: %d\n", i+1, ldrVal);
    updateLightingFromLDR(ldrVal, ledStrips[i]);
  }
}
