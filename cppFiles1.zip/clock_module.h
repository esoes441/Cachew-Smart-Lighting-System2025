#ifndef CLOCK_MODULE_H
#define CLOCK_MODULE_H

void initRTC();
void updateTimeAndReport();

#endif