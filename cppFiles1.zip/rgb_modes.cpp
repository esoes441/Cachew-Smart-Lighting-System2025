#include "rgb_modes.h"
#include "config.h"
#include <Adafruit_NeoPixel.h>

// Control the first strip or broadcast to all strips
extern Adafruit_NeoPixel* ledStrips[];

void setRGBColor(int r, int g, int b) {
  for (int i = 0; i < NUM_LDR_SENSORS; i++) {
    for (int j = 0; j < NUM_LEDS; j++) {
      ledStrips[i]->setPixelColor(j, ledStrips[i]->Color(r, g, b));
    }
    ledStrips[i]->show();
  }
}

void setPartyMode() {   //özelle
  setRGBColor(255, 0, 255); // Purple
}

void setMovieMode() {
  setRGBColor(10, 10, 30);  // Dim blue
}

void setDinnerMode() {
  setRGBColor(255, 150, 50); // Warm orange
}